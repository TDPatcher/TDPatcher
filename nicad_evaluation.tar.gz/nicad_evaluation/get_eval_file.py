import os

base_dir = '../NiCad-6.2/systems_block/'

for i in range(1129):
    src_path = base_dir  + str(i) + '_blocks-blind-clones'
    src_file = str(i)  + '_blocks-blind-clones-0.30.xml'
    # print(src_path)
    cp_cmd = "cp " + src_path + '/'  + src_file + " " + './block/'
    os.system(cp_cmd) 
    # break

