import os
import pickle

with open('./block-clone_groups.pkl', 'rb') as handler:
    clone_groups = pickle.load(handler)

def verify_function(e): 
    fpath = '../NiCad-6.2/' + e[0]
    fstart = e[1]
    fend = e[2]
    source_code = [] 
    with open(fpath, 'r') as fp:
       for i, line in enumerate(fp):
           if i >= int(fstart) and i <= int(fend):
               source_code.append(line.lower()) 
    source_code = ' '.join(source_code)
    if "todo"  in source_code:
        return 1
    else:
        return 0

true_positive = 0
false_positive = 0 
for clone_group in clone_groups:
    print(clone_group)
    assert len(clone_group) == 2
    group_result = []
    for e in clone_group:
        r = verify_function(e) 
        group_result.append(r)
        # print(r)
        if group_result == [1, 1]:
           true_positive += 1  
        if group_result == [0, 1]:
           false_positive += 1
        if group_result == [1, 0]: 
           false_positive += 1

false_negative = 1129 - true_positive  
true_negative = 16541 - 1129 - false_positive  
print(true_positive)
print(false_positive)
print(false_negative)
print(true_negative)
    # break
precision = true_positive * 1.0 / (true_positive + false_positive)
recall = true_positive *1.0 / (true_positive + false_negative)
f1 = 2.0 * true_positive / (2.0 * true_positive + false_positive + false_negative)
print(precision, recall, f1)

